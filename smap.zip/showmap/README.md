### showmap

A simple demo of process map.

Compile using: `make`.

